<div style='text-align: center'>
<p> Information Technology,Ratnagiri<br/>
<?php
date_default_timezone_set("Asia/Calcutta");
echo 'Today is ';
echo date('dS F ');
echo ',';
echo date('Y');
?>
<br/>
</div>

