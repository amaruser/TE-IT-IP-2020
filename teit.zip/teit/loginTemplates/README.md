# Login and Signup template using Bootstrap framework

Bootstrap example of Login and Registration form made with bootstrap using HTML, Javascript, jQuery, and CSS. The template is available for free download here.

* <strong><a href="https://easytousecode.github.io/login-signup/">Live Demo </a></strong>
* <strong><a href="https://github.com/easytousecode/login-signup/archive/gh-pages.zip">Download </a></strong>