<?php

$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);


$query="SELECT fname,mno FROM students";



$result = $conn->query($query);




//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  
{
	$dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);

?>





