<?php
  

$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

  


$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

//echo "Connected successfully \n";
echo ("<br/>");



 

  //echo "Database $db_name selected.\n";
echo ("<br/>");

$username=$_POST['txt1'];

$password=$_POST['txt2'];


$query="SELECT * FROM login WHERE username = '$username'";

$result = $conn->query($query);




$rows = $result->num_rows;


if($rows > 0)
{
 while($row = mysqli_fetch_array($result))  
                {  
                     if(password_verify($password, $row["password"]))  
                     { 
		 session_start();
   		$_SESSION['login'] = "1";
		$_SESSION['username'] = $username;

		 header ("Location: http://192.168.1.100/teit/protected.php");
		//echo("<P>Success </P>");
		
		     }

		   else
		   {
               	   echo("<P>Password is wrong,retry </P>");
		echo("<a href='http://192.168.1.100/teit/login.html'>Back to Main Page</a>");
		   }
 		
                }
 }
else
{
 echo("<P>Error in logging </P>"); 
   session_start();
   $_SESSION['login'] = '';
 
echo("<a href='http://192.168.1.100/teit/login.html'>Back to Main Page</a>");
}


$result->close();
$conn->close();
?>
