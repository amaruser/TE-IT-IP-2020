<?php
  $db_host = "localhost";
  $db_username = "root";
  $db_passwd = "amar1296";
  $db= @mysql_connect($db_host, $db_username, $db_passwd) or die ("Could not connect!\n");


  echo "Connection established.\n";
  $db_name = "seit";
 
$db_found=@mysql_select_db("$db_name") or die ("Could not select the database.\n $dbname");
 

  echo "Database $db_name selected.\n";

$username=$_POST['txt1'];
$password=$_POST['txt2'];

$sql="SELECT * FROM login WHERE L1 = $username AND L2 = $password";




  if (mysql_query($sql)) 
{
    echo("welcome $username ");
  } 
else 
{
    echo("<P>Error in logging </P>"); 
 
echo("<a href='http://127.0.0.1/home1.html'>Back to Main Page</a>");
}
mysql_close($db);
?>
