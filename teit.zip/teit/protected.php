
<?php

session_start();
if ((isset($_SESSION['login']) && $_SESSION['login'] != ''))
{
header("location:http://192.168.1.100/teit/searchstudents.php");
}
//echo "(Protected page,u have securely logged-in)";
echo("<A HREF = http://192.168.1.100/teit/logout.php>Log out</A>")
?>
