<?php

$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);

$user=$_GET['txt1'];

if(strlen($user)<4)
{
echo ("<font color=red>criteria failed,</font>")."<i><font color=green>username must have more than 3 characters</font></i>";
exit;
}
$query="SELECT * FROM login WHERE username LIKE '$user'";
$result = $conn->query($query);
$rows = $result->num_rows;


if($rows > 0)
{
echo "<font size='3' color='red'>No,you can't choose this</font>";

}
else
{
echo "<font size='3' color='green'>Yes,you can choose this</font>";
}


?>





