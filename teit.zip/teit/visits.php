<?php
$Cookie_period=time()+60*60*24*30;


 
 if(isset($_COOKIE['visits']))
  { 
   $count=$_COOKIE['visits']+1;
   setcookie("visits",$count,$Cookie_period);
   echo ("<h3> You have visited this page earlie $count times</h3>");
  }
 else
  {
  
   $count=0;
   setcookie("visits",$count,$Cookie_period);
  echo ("<h3>Welcome ,its your first visit </h3>");
  }
?>
