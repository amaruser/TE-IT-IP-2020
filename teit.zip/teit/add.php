

<?php
session_start();
if ((!(isset($_SESSION['login'])) && $_SESSION['login'] == ''))
{
header("location:http://192.168.1.100/teit/login.html");
}
//echo "(Protected page,u have securely logged-in)";
echo ("Welcome ");
echo ($_SESSION['username']);
echo ("<p align='right'>");
echo("<A HREF = http://192.168.1.100/teit/logout.php>Log out</A>");
echo ("</p>");

?>

<!DOCTYPE html>
<html>

<title> Adding students data </title>
<body bgcolor="skyblue">

<?php include 'header.php'; ?>

<p align=center><font size=6 color=white> Adding records ... </font></p>
<form name="A" method="post" action="http://192.168.1.100/teit/insert.php">
Enetr full name:<input type="text" name="txt1"><br/>
Enter Mobile number:<input type="text" name="txt2"></br>
Enter email id:<input type="email" name="txt3"></br>
<input type="submit" value="SAVE">


</form>
</body>
</html>
