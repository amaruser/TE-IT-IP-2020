

<?php
session_start();
if ((!(isset($_SESSION['login'])) && $_SESSION['login'] == ''))
{
header("location:http://192.168.1.100/teit/login.html");
}
//echo "(Protected page,u have securely logged-in)";



$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

  


$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);


$query="SELECT * FROM student";

$result = $conn->query($query);


$rows = $result->num_rows;


if($rows > 0)
{

?>
<body>
<?php include 'header.php'; ?>
<center> Records fetched from database </center>
<table border="1" align="center">
<tr>
<th>Full Name</th>
<th>Mobile No</th>
<th>E mail ID</th>
</tr>

<?php

 while($row = mysqli_fetch_array($result))  
                {  
	         echo ("<tr>");
		echo ("<td>");
		echo($row["fname"]);
		echo ("</td>");

		echo ("<td>");
		echo($row["mno"]);
		echo ("</td>");

		echo ("<td>");
		echo($row["eid"]);
		echo ("</td>");
		echo ("</tr>");

             //echo "$row[fname], $row[mno],$row[eid]";
		//echo ("<br/>");
		}

echo ("</table>");
echo ("Total record found $rows");
  
}

else

{

echo ("No records found");
 }
?>
