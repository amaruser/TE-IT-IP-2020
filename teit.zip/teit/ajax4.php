<?php

$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);

$user=$_GET['txt1'];

if($user=="")
{
$query="SELECT * FROM students WHERE fname LIKE '$user'";
}
else
{
$query="SELECT * FROM students WHERE fname LIKE '$user%'";
}


$result = $conn->query($query);
$result1 = $conn->query($query);
$result2 = $conn->query($query);
$rows = $result->num_rows;

$ans1=" ";
for ($j = 0 ; $j < $rows ; ++$j)
{

$result->data_seek($j);
$result1->data_seek($j);
$result2->data_seek($j);
$reslt=$result2->fetch_assoc()['ml'];


$ans=$result->fetch_assoc()['fname']." --".$result1->fetch_assoc()['mno']."--".$reslt.'<br>';


$ans1=$ans.$ans1;


}
echo "$rows $ans1";


?>





