<?php
date_default_timezone_set('Asia/Kolkata');
$cookie_period=2+time(); 
$at=date("h:i:s a d/m/y");
 
//setcookie('lastvisit',$at,$cookie_period);

if(isset($_COOKIE["lastVisit"])) 
{ 
 
 $visit=$_COOKIE["lastVisit"]; 
 setcookie('lastVisit',$at,$cookie_period);
 echo "Your last visit was at- ".$visit; 
} 
 
else 
{

echo "This is your first visit at";
echo(date("h:i:s A")); 
 setcookie('lastVisit',$at,$cookie_period);
}
?> 
