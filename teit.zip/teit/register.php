<?php
  

$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

  


$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);


 


$username=$_POST['txt1'];
$password=$_POST['txt2'];


$query="SELECT * FROM login WHERE username = '$username'";

$result = $conn->query($query);

$rows = $result->num_rows;


if($rows > 0)
{

echo ("$username is already in use,choose differenet<br>");
echo("<a href='http://192.168.1.100/teit/register.html'>Retry ..</a>");
die("Cannot proceed further ...");

}


$password_encrypted = password_hash($password, PASSWORD_BCRYPT);
//$password_encrypted="ok";
$query1="INSERT INTO login (username, password) VALUES ('$username','$password_encrypted')";


$result1 = mysqli_query($conn,$query1);

if(! $result1 ) 
{
      echo("<P>Error in logging </P>"); 
   session_start();
   $_SESSION['login'] = '';
 
echo("<a href='http://192.168.1.100/teit/login.html'>Back to Main Page</a>");
   }
   else
{

   session_start();
   $_SESSION['login'] = "1";
    echo("<P>Registred successfully </P>");

    
 //header ("Location: http://192.168.1.100/teit/protected.php");

}


$result->close();

$conn->close();
echo("<a href='http://192.168.1.100/teit/login.html'>Back to Login Page</a>");
?>
