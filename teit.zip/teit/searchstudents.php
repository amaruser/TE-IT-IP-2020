

<?php

session_start();
if ((!(isset($_SESSION['login'])) && $_SESSION['login'] == ''))
{
header("location:http://192.168.1.100/teit/login.html");
}
//echo "(Protected page,u have securely logged-in)";
echo ("Welcome ");
echo ($_SESSION['username']);
echo ("<p align='right'>");
echo("<A HREF = http://192.168.1.100/teit/logout.php>Log out</A>");
echo ("</p>");

?>


<html>
<head>
<style type="text/css">
.box 
{ 
border: 1px solid black;
padding: 20px;
background-color:pink
 }
</style>


<script type = "text/javascript" language = "JavaScript">

var asyncRequest; 

function getContent( url,ch)
{

try
{
var ch1=ch
asyncRequest = new XMLHttpRequest(); 
url1=url+"?txt1="+ch1
//alert(url1)
asyncRequest.onreadystatechange = stateChange;
asyncRequest.open( 'GET', url1, true ); 
asyncRequest.send( null ); 
} 


catch ( exception )
{
alert( 'Request failed.' );
} 
} 

function stateChange()
{
if ( asyncRequest.readyState == 4 && asyncRequest.status == 200 )
{

var rt=asyncRequest.responseText;

var ans1=rt.substring(2,rt.length)




document.getElementById( 'contentArea' ).innerHTML =ans1



//document.getElementById( 'contentArea' ).innerHTML =asyncRequest.responseText; 



var ans=rt.substring(0,2)
document.getElementById( 'sp1' ).innerHTML =ans 
} 
} 

function clearContent()
{
document.getElementById( 'contentArea' ).innerHTML = '';
} 

</script>



</head>
<title> Search In Form </title>
<body bgcolor="skyblue">

<?php include 'header.php'; ?>

<p align=center><font size=6 color=white> TE-IT Students database </font></p>

<p>Type student name here(start with surnmae):<input type="text" id="uname" name="txt1" onkeyup='getContent("http://192.168.1.100/teit/ajax4.php",this.value)'>

<font size=3 color=yellow><span id="sp1"> </span> Records found</font>
<div class = "box" id = "contentArea">&nbsp;</div>
<a href="http://192.168.1.100/teit/add.php">Add more students info </a>

<p align="right"><a href="http://192.168.1.100/teit/showall.php">Show all students info </a></p>
</form>
</body>
</html>
