<?php
//echo phpinfo();

echo ("<p>Para tag </p>"); 
?>
