

<?php

session_start();
if ((!(isset($_SESSION['login'])) && $_SESSION['login'] == ''))
{
header("location:http://192.168.1.100/teit/login.html");
}

?>

<?php


$db_host = 'localhost';
$db_name = 'teit';
$db_username = 'root';
$db_passwd = 'Bhy:Y-e..6Dc';

  


$conn = mysqli_connect($db_host, $db_username, $db_passwd,$db_name);


 


$fname=$_POST['txt1'];
$mno=$_POST['txt2'];
$eid=$_POST['txt3'];

$query="INSERT INTO student (fname, mno,eid) VALUES ('$fname','$mno','$eid')";

$result = mysqli_query($conn,$query);

if(! $result ) 
{
      echo("<P>Error in addind data </P>"); 

   //session_start();
   $_SESSION['login'] = '';
 
echo("<a href='http://192.168.1.100/teit/login.html'>Back to Main Page</a>");
   }
   else
{

   //session_start();
   $_SESSION['login'] = "1";
    echo("<P>successfully added data </P>");
//$result->close();



}




$conn->close();
echo("<a href='http://192.168.1.100/teit/login.html'>Back to Login Page</a>");
?>

